November 3 1999

RELEASE NOTES:

These .zip files contain the sources for the modified versions of the original 
Genesis 3D Direct3d and Glide drivers. 

They have been released as per the Genesis 3D Open Source Agreement covering source 
modifications. 

Modifications:

Implemented linear distance fogging in D3D and Glide


CREDITS:

Original codebase (C) Eclipse Entertainment
Original D3D fog code written by Jeff Kaye
Original Glide fog code written by Mark O'Hara
Additional code modifications and implementations by Matt Aufderheide

For more information about these sources please visit www.ingava.com.
